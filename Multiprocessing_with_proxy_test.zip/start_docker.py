# import docker
# import dockerpty
#
# client = docker.from_env()
# client.containers.run(image="machine1", detach=True)
# client.containers.run(image="machine2", detach=True)
# client.containers.run(image="machine3", detach=True)

docker run -v /Users/spider/job/projects/for_test/test_Oxy_lab/multi_process/Dist/machine1:/machine machine1